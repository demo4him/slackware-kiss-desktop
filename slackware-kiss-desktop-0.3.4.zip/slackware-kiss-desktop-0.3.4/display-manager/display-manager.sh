#!/bin/bash
# Slackware KISS Desktop - LXDM only
# Slackware 15.0

set -Eeuo pipefail

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

[[ $EUID -eq 0 ]] || fail "Run this script as root."
[[ -r /etc/slackware-version ]] || fail "Cannot detect Slackware version."
[[ $(cat /etc/slackware-version) == "Slackware 15.0" ]] ||
    fail "This module targets Slackware 15.0."

command -v dialog >/dev/null 2>&1 || fail "dialog is not installed."
command -v loginctl >/dev/null 2>&1 || fail "loginctl is required."
command -v getent >/dev/null 2>&1 || fail "getent is required."

dialog --clear --backtitle "Slackware KISS Desktop" \
    --title " LXDM - Display Manager " \
    --yesno "Install and configure LXDM?\n\nOnly LXDM will be configured.\nAutomatic login will be enabled for the detected local user.\nRunlevel 4 will become the default." \
    12 72 || {
        clear || true
        echo "Operation cancelled. Nothing was changed."
        exit 0
    }
clear || true

# Identify exactly one active, local desktop session.
DESKTOP_UIDS=()

while read -r SESSION_ID _; do
    [[ -n ${SESSION_ID:-} ]] || continue

    SESSION_INFO=$(loginctl show-session "$SESSION_ID" \
        -p User -p Seat -p Active -p Remote 2>/dev/null) || continue

    SESSION_UID=$(awk -F= '$1=="User"{print $2}' <<< "$SESSION_INFO")
    SESSION_SEAT=$(awk -F= '$1=="Seat"{print $2}' <<< "$SESSION_INFO")
    SESSION_ACTIVE=$(awk -F= '$1=="Active"{print $2}' <<< "$SESSION_INFO")
    SESSION_REMOTE=$(awk -F= '$1=="Remote"{print $2}' <<< "$SESSION_INFO")

    if [[ $SESSION_UID =~ ^[0-9]+$ &&
          -n $SESSION_SEAT &&
          $SESSION_ACTIVE == yes &&
          $SESSION_REMOTE == no ]]; then
        DESKTOP_UIDS+=("$SESSION_UID")
    fi
done < <(loginctl list-sessions --no-legend)

((${#DESKTOP_UIDS[@]} > 0)) ||
    fail "No active local desktop user was detected."

mapfile -t DESKTOP_UIDS < <(printf '%s\n' "${DESKTOP_UIDS[@]}" | sort -un)

((${#DESKTOP_UIDS[@]} == 1)) ||
    fail "Could not identify exactly one active local desktop user."

DESKTOP_UID=${DESKTOP_UIDS[0]}
PASSWD_ENTRY=$(getent passwd "$DESKTOP_UID") ||
    fail "Cannot resolve desktop UID through getent."

IFS=: read -r DESKTOP_USER _ _ _ _ DESKTOP_HOME _ <<< "$PASSWD_ENTRY"

[[ -n $DESKTOP_USER && -n $DESKTOP_HOME && $DESKTOP_USER != root ]] ||
    fail "Invalid desktop user or home directory."

echo "Desktop user detected: $DESKTOP_USER"
echo "Home directory detected: $DESKTOP_HOME"

# Validate rc.4 before installing or changing anything.
RC4=/etc/rc.d/rc.4
[[ -f $RC4 ]] || fail "Slackware rc.4 is missing."

if [[ -x /etc/rc.d/rc.4.local ]]; then
    fail "Executable rc.4.local overrides rc.4; configure it separately."
fi

RC4_MARKER="# BEGIN SLACKWARE-KISS DISPLAY MANAGER"
RC4_END="# END SLACKWARE-KISS DISPLAY MANAGER"
GDM_MARKER="# Try to use GNOME's gdm session manager"

awk -v gdm="$GDM_MARKER" -v begin="$RC4_MARKER" -v end="$RC4_END" '
    index($0,gdm)==1 { gdm_count++ }
    $0==begin {
        if (inside) bad=1
        inside=1
        begin_count++
    }
    $0==end {
        if (!inside) bad=1
        inside=0
        end_count++
    }
    END {
        if (inside || bad || gdm_count!=1 ||
            begin_count!=end_count || begin_count>1)
            exit 1
    }
' "$RC4" || fail "Unsafe rc.4 structure; no changes were made."

# Install LXDM only if it is not already installed.
if compgen -G "/var/log/packages/lxdm-[0-9]*" > /dev/null; then
    echo "LXDM is already installed."
else
    [[ -x /usr/sbin/sbopkg ]] || fail "sbopkg is not installed."
    echo "Building and installing LXDM..."
    /usr/sbin/sbopkg -i lxdm || fail "LXDM installation failed."
fi

LXDM_BIN=$(command -v lxdm) ||
    fail "LXDM executable was not found after installation."

LXDM_CONF=/etc/lxdm/lxdm.conf
LXDM_PAM=/etc/pam.d/lxdm

[[ -f $LXDM_CONF ]] || fail "LXDM configuration is missing."
[[ -f $LXDM_PAM ]] || fail "LXDM PAM configuration is missing."

backup_file() {
    local file=$1
    local backup="${file}.bak-kiss-$(date +%Y%m%d-%H%M%S)"

    cp -p -- "$file" "$backup" ||
        fail "Cannot back up $file"

    echo "Backup created: $backup"
}

# Enable LXDM autologin for the dynamically detected desktop user.
TMP_CONF=$(mktemp /etc/lxdm/.lxdm.conf.XXXXXX) ||
    fail "Cannot create temporary LXDM configuration."

awk -v user="$DESKTOP_USER" '
    /^\[/ {
        if (inbase && !inserted) {
            print "autologin=" user
            inserted=1
        }
        inbase=($0=="[base]")
        if (inbase) base_count++
        print
        next
    }
    inbase && /^[[:space:]]*#?[[:space:]]*autologin[[:space:]]*=/ {
        next
    }
    { print }
    END {
        if (inbase && !inserted) {
            print "autologin=" user
            inserted=1
        }
        if (base_count != 1 || !inserted) exit 2
    }
' "$LXDM_CONF" > "$TMP_CONF" ||
    fail "Cannot safely update LXDM configuration."

chmod --reference="$LXDM_CONF" "$TMP_CONF"
chown --reference="$LXDM_CONF" "$TMP_CONF"
backup_file "$LXDM_CONF"
mv "$TMP_CONF" "$LXDM_CONF"

# Add elogind PAM support exactly after system-auth.
if ! grep -Eq '^[[:space:]]*session[[:space:]]+optional[[:space:]]+pam_elogind\.so([[:space:]]|$)' "$LXDM_PAM"; then
    TMP_PAM=$(mktemp /etc/pam.d/.lxdm.XXXXXX) ||
        fail "Cannot create temporary PAM configuration."

    awk '
        { print }
        $1=="session" && $2=="include" && $3=="system-auth" {
            matches++
            print "session optional pam_elogind.so"
        }
        END {
            if (matches != 1) exit 2
        }
    ' "$LXDM_PAM" > "$TMP_PAM" ||
        fail "Cannot safely update LXDM PAM configuration."

    chmod --reference="$LXDM_PAM" "$TMP_PAM"
    chown --reference="$LXDM_PAM" "$TMP_PAM"
    backup_file "$LXDM_PAM"
    mv "$TMP_PAM" "$LXDM_PAM"
fi

# Integrate LXDM into Slackware rc.4.
backup_file "$RC4"

TMP_RC4=$(mktemp /etc/rc.d/.rc.4.XXXXXX) ||
    fail "Cannot create temporary rc.4."

awk -v begin="$RC4_MARKER" -v end="$RC4_END" '
    $0==begin { skip=1; next }
    skip && $0==end { skip=0; next }
    !skip { print }
' "$RC4" > "$TMP_RC4"

DM_BLOCK=$(printf '%s\n' \
    "$RC4_MARKER" \
    "if [ -x \"$LXDM_BIN\" ]; then" \
    "  exec \"$LXDM_BIN\" -nodaemon" \
    "fi" \
    "$RC4_END")

awk -v block="$DM_BLOCK" -v marker="$GDM_MARKER" '
    index($0,marker)==1 { print block }
    { print }
' "$TMP_RC4" > "${TMP_RC4}.new"

mv "${TMP_RC4}.new" "$TMP_RC4"
chmod --reference="$RC4" "$TMP_RC4"
chown --reference="$RC4" "$TMP_RC4"

bash -n "$TMP_RC4" ||
    fail "Generated rc.4 failed syntax validation."

mv "$TMP_RC4" "$RC4"

# Enable graphical runlevel 4 as the default.
INITTAB=/etc/inittab
[[ -f $INITTAB ]] || fail "Slackware inittab is missing."

TMP_INITTAB=$(mktemp /etc/.inittab.XXXXXX) ||
    fail "Cannot create temporary inittab."

awk '
    /^[[:space:]]*id:[34]:initdefault:[[:space:]]*$/ {
        matches++
        if ($0 ~ /id:3:initdefault:/) {
            sub(/id:3:initdefault:/, "id:4:initdefault:")
            changed=1
        }
    }
    { print }
    END {
        if (matches != 1) exit 2
    }
' "$INITTAB" > "$TMP_INITTAB" || {
    rm -f "$TMP_INITTAB"
    fail "Cannot safely configure the default runlevel."
}

if ! cmp -s "$INITTAB" "$TMP_INITTAB"; then
    backup_file "$INITTAB"
    chmod --reference="$INITTAB" "$TMP_INITTAB"
    chown --reference="$INITTAB" "$TMP_INITTAB"
    mv "$TMP_INITTAB" "$INITTAB"
else
    rm -f "$TMP_INITTAB"
    echo "Runlevel 4 is already the default."
fi

echo
echo "LXDM configuration completed."
echo "Display manager: $LXDM_BIN"
echo "Desktop user detected: $DESKTOP_USER"
echo "Authentication: automatic login"
echo "Automatic login: enabled for $DESKTOP_USER"
echo "Runlevel 4: enabled as default"
