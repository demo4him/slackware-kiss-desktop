#!/bin/bash
# Slackware KISS Desktop - SBo package selection

set -Eeuo pipefail

[[ $EUID -eq 0 ]] || {
    echo "ERROR: Run this script as root."
    exit 1
}

[[ -r /etc/slackware-version ]] &&
[[ $(cat /etc/slackware-version) == "Slackware 15.0" ]] || {
    echo "ERROR: This module targets Slackware 15.0."
    exit 1
}

command -v dialog >/dev/null 2>&1 || {
    echo "ERROR: dialog is not installed."
    exit 1
}

[[ -x /usr/sbin/sbopkg ]] || {
    echo "ERROR: sbopkg is not installed."
    exit 1
}

TMP_SELECTION=$(mktemp)
trap 'rm -f "$TMP_SELECTION"' EXIT
trap 'exit 1' HUP INT TERM

dialog --clear --separate-output \
    --backtitle "Slackware KISS Desktop" \
    --title " SlackBuilds.org - Package Selection " \
    --checklist "Use SPACE to select packages and ENTER to confirm:" \
    18 76 4 \
    xarchiver "Archive manager" OFF \
    thunar-archive-plugin "Thunar archive integration" OFF \
    xfce4-genmon-plugin "Generic monitor plugin" OFF \
    xfce4-xkb-plugin "Keyboard layout plugin" OFF \
    2>"$TMP_SELECTION" || {
        clear || true
        echo "Selection cancelled. Nothing was installed."
        exit 0
    }

clear || true

mapfile -t SELECTED_PACKAGES < "$TMP_SELECTION"

((${#SELECTED_PACKAGES[@]} > 0)) || {
    echo "No packages selected. Nothing to install."
    exit 0
}

for PACKAGE in "${SELECTED_PACKAGES[@]}"; do
    echo
    echo "Building and installing: $PACKAGE"
    /usr/sbin/sbopkg -i "$PACKAGE" || {
        echo "ERROR: Installation failed for $PACKAGE."
        exit 1
    }
done

echo
echo "SBo operations completed."
