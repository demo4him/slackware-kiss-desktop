#!/bin/bash
# Slackware KISS Desktop 0.3.4 - dynamic MLED-style package inventory/audit.
# Unknown names and duplicate installed versions are preserved, never auto-removed.

set -Eeuo pipefail

PROGRAM=${0##*/}
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd -- "$SCRIPT_DIR/.." && pwd)
TAGFILES_DIR="$ROOT_DIR/tagfiles"
XFCE_INVENTORY="$ROOT_DIR/xfce/packages-official"
XFCE_SELECTION="$ROOT_DIR/pkglists/xfce-selected"
ADD_LIST="$ROOT_DIR/pkglists/packages-add"
KEEP_LIST="$ROOT_DIR/pkglists/packages-keep"
REMOVE_LIST="$ROOT_DIR/pkglists/packages-remove"
PACKAGE_DB=${KISS_PACKAGE_DB:-/var/log/packages}
OUTPUT='-'

usage() {
  cat <<USAGE
Usage: $PROGRAM [--package-db DIR] [--output FILE]

Build ADD/REMOVE manifests from the nine project tagfiles and the live
Slackware package database. Unknown package-log formats and duplicate
installed versions are preserved and reported; they are never auto-removed.

Options:
  --package-db DIR  Installed package log directory (default: /var/log/packages)
  --output FILE     Write TSV report to FILE instead of standard output
  -h, --help        Show this help
USAGE
}

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
while (($#)); do
  case $1 in
    --package-db) (($# >= 2)) || fail '--package-db requires a directory'; PACKAGE_DB=$2; shift 2 ;;
    --output) (($# >= 2)) || fail '--output requires a file'; OUTPUT=$2; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

[[ -d $PACKAGE_DB ]] || fail "Package database not found: $PACKAGE_DB"
[[ -d $TAGFILES_DIR ]] || fail "Tagfiles directory not found: $TAGFILES_DIR"
[[ -r $XFCE_INVENTORY && -r $KEEP_LIST ]] || fail 'Required keep inventories are missing.'
[[ -r $XFCE_SELECTION ]] || fail "XFCE selection is missing. Run xfce/install-xfce.sh before MLED Trim."

trim_line() {
  local value=$1
  value=${value#"${value%%[!$' \t\r\n']*}"}
  value=${value%"${value##*[!$' \t\r\n']}"}
  printf '%s' "$value"
}
valid_package_name() { [[ $1 =~ ^[A-Za-z0-9._+-]+$ ]]; }

# Slackware package log grammar: NAME-VERSION-ARCH-BUILD. VERSION and BUILD
# may start with letters (e.g. cdparanoia III_10.2); architecture is explicit.
parse_log_name() {
  local filename=$1
  if [[ $filename =~ ^(.+)-([A-Za-z0-9][A-Za-z0-9._+~-]*)-(x86_64|x86|noarch|i[3-6]86)-([A-Za-z0-9][A-Za-z0-9._+~-]*)$ ]]; then
    PARSED_PACKAGE=${BASH_REMATCH[1]}
    PARSED_VERSION=${BASH_REMATCH[2]}
    PARSED_ARCH=${BASH_REMATCH[3]}
    PARSED_BUILD=${BASH_REMATCH[4]}
    return 0
  fi
  return 1
}

declare -A ADD_SET=() KEEP_SET=() XFCE_SET=()
declare -A LOG_COUNT=() LOG_BASE=()
EXPECTED_SERIES=(a ap d k l n t x xap)
shopt -s nullglob
tagfiles=("$TAGFILES_DIR"/*/tagfile)
((${#tagfiles[@]} == 9)) || fail "Expected exactly 9 tagfiles; found ${#tagfiles[@]}."
for series in "${EXPECTED_SERIES[@]}"; do
  [[ -r "$TAGFILES_DIR/$series/tagfile" ]] || fail "Required tested tagfile is missing: $series/tagfile"
done
for tagfile in "${tagfiles[@]}"; do
  while IFS= read -r line || [[ -n $line ]]; do
    line=$(trim_line "$line")
    [[ -z $line || $line == \#* ]] && continue
    [[ $line == *:* ]] || fail "Malformed tagfile entry in $tagfile: $line"
    package=${line%%:*}; state=${line##*:}
    valid_package_name "$package" || fail "Invalid package name in $tagfile: $package"
    case $state in
      ADD) ADD_SET["$package"]=1; KEEP_SET["$package"]=1 ;;
      SKP) ;;
      *) fail "Unknown tagfile state '$state' in $tagfile for $package" ;;
    esac
  done < "$tagfile"
done

while IFS= read -r line || [[ -n $line ]]; do
  line=$(trim_line "$line"); [[ -z $line || $line == \#* ]] && continue
  valid_package_name "$line" || fail "Invalid package name in XFCE inventory: $line"
  XFCE_SET["$line"]=1
done < "$XFCE_INVENTORY"

xfce_count=0
while IFS= read -r line || [[ -n $line ]]; do
  line=$(trim_line "$line"); [[ -z $line || $line == \#* ]] && continue
  valid_package_name "$line" || fail "Invalid package name in XFCE selection: $line"
  [[ ${XFCE_SET[$line]-} == 1 ]] || fail "Selected XFCE package is not in official inventory: $line"
  KEEP_SET["$line"]=1; ((xfce_count+=1))
done < "$XFCE_SELECTION"
((xfce_count > 0)) || fail "XFCE selection is empty; refusing to generate a trim manifest."

while IFS= read -r line || [[ -n $line ]]; do
  line=$(trim_line "$line"); [[ -z $line || $line == \#* ]] && continue
  valid_package_name "$line" || fail "Invalid package name in packages-keep: $line"
  KEEP_SET["$line"]=1
done < "$KEEP_LIST"

TMP_ADD=$(mktemp "$ROOT_DIR/pkglists/.packages-add.XXXXXX")
TMP_REMOVE=$(mktemp "$ROOT_DIR/pkglists/.packages-remove.XXXXXX")
TMP_REPORT=$(mktemp)
cleanup() { rm -f "$TMP_ADD" "$TMP_REMOVE" "$TMP_REPORT"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
for package in "${!ADD_SET[@]}"; do printf '%s\n' "$package"; done | LC_ALL=C sort > "$TMP_ADD"

# First pass: derive exact package base names and count installed log records.
# A duplicate base name (e.g. two e2fsprogs versions) is protected as a group.
count_total=0; count_nonstandard=0; count_duplicate_logs=0
for log in "$PACKAGE_DB"/*; do
  [[ -f $log ]] || continue
  filename=${log##*/}
  ((count_total+=1))
  if parse_log_name "$filename"; then
    package=$PARSED_PACKAGE
    LOG_BASE["$filename"]=$package
    LOG_COUNT["$package"]=$(( ${LOG_COUNT[$package]:-0} + 1 ))
  else
    LOG_BASE["$filename"]=''
    ((count_nonstandard+=1))
  fi
done

printf 'PACKAGE\tVERSION\tARCH\tBUILD\tINSTALLED_LOG\tCLASSIFICATION\tDECISION\tREASON\n' > "$TMP_REPORT"
count_keep=0; count_remove=0; count_duplicate_packages=0
for log in "$PACKAGE_DB"/*; do
  [[ -f $log ]] || continue
  filename=${log##*/}
  if [[ -n ${LOG_BASE[$filename]} ]]; then
    package=${LOG_BASE[$filename]}
    parse_log_name "$filename" || fail "Internal package-log parsing inconsistency: $filename"
    version=$PARSED_VERSION; arch=$PARSED_ARCH; build=$PARSED_BUILD
    if (( ${LOG_COUNT[$package]} > 1 )); then
      decision=KEEP-DUPLICATE
      reason='Multiple installed logs share this exact package base name; preserved pending manual package-database review'
      classification=DUPLICATE
      ((count_duplicate_packages+=1))
      ((count_keep+=1))
    elif [[ $package == *-compat32 ]]; then
      decision=KEEP-COMPAT32
      reason='32-bit compatibility package; preserved separately from its native package'
      classification=COMPAT32
      ((count_keep+=1))
    elif [[ ${KEEP_SET[$package]-} == 1 ]]; then
      decision=KEEP
      reason='Selected by tagfile ADD, selected XFCE profile, or explicit packages-keep'
      if [[ ${ADD_SET[$package]-} == 1 ]]; then classification=TAGFILE-ADD
      elif [[ ${XFCE_SET[$package]-} == 1 ]]; then classification=XFCE-SELECTED
      else classification=EXPLICIT-KEEP; fi
      ((count_keep+=1))
    else
      decision=REMOVE
      reason='Unique standard package outside the selected KISS/MLED keep set'
      classification=UNSELECTED
      printf '%s\n' "$package" >> "$TMP_REMOVE"
      ((count_remove+=1))
    fi
  else
    package=$filename; version=''; arch=''; build=''
    classification=NONSTANDARD
    decision=KEEP-NONSTANDARD
    reason='Unrecognized package-log format; preserved automatically because package identity is uncertain'
    ((count_keep+=1))
  fi
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$package" "$version" "$arch" "$build" "$filename" "$classification" "$decision" "$reason" >> "$TMP_REPORT"
done

LC_ALL=C sort -u "$TMP_REMOVE" -o "$TMP_REMOVE"
chmod 0644 "$TMP_ADD" "$TMP_REMOVE"
mv -f -- "$TMP_ADD" "$ADD_LIST"
mv -f -- "$TMP_REMOVE" "$REMOVE_LIST"
if [[ $OUTPUT == '-' ]]; then cat "$TMP_REPORT"
else mkdir -p -- "$(dirname -- "$OUTPUT")"; cp "$TMP_REPORT" "$OUTPUT"; fi

printf '\nDynamic MLED inventory and manifest generation complete.\n' >&2
printf 'Installed logs: %s | KEEP: %s | REMOVE: %s | Non-standard preserved: %s | Duplicate package bases: %s | ADD entries: %s\n' \
  "$count_total" "$count_keep" "$count_remove" "$count_nonstandard" "$count_duplicate_packages" "${#ADD_SET[@]}" >&2
printf 'Generated: %s, %s\n' "$ADD_LIST" "$REMOVE_LIST" >&2
printf 'No package operation was executed by this audit.\n' >&2
