#!/bin/bash
# Slackware KISS Desktop 0.3.4 - MLED-style manifest generator
# ADD tagfile packages first; remove every installed package outside the
# selected tagfile/XFCE/SBo keep set. No dependency audit by design.

set -Eeuo pipefail

PROGRAM=${0##*/}
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd -- "$SCRIPT_DIR/.." && pwd)
TAGFILES_DIR="$ROOT_DIR/tagfiles"
XFCE_INVENTORY="$ROOT_DIR/xfce/packages-official"
XFCE_SELECTION="$ROOT_DIR/pkglists/xfce-selected"
ADD_LIST="$ROOT_DIR/pkglists/packages-add"
KEEP_LIST="$ROOT_DIR/pkglists/packages-keep"
REMOVE_LIST="$ROOT_DIR/pkglists/packages-remove"
PACKAGE_DB=${KISS_PACKAGE_DB:-/var/log/packages}
OUTPUT='-'

usage() {
  cat <<USAGE
Usage: $PROGRAM [--package-db DIR] [--output FILE]

Generate MLED-style package manifests for Slackware64 15.0:
  packages-add    = every ADD entry from the nine project tagfiles
  packages-remove = every installed package outside ADD + selected XFCE + packages-keep

SKP entries are not selected and are therefore removal candidates when installed.
No dependency analysis is performed, as specified by the project policy.
The generated lists are reviewed by kiss-trim.sh before any package operation.

Options:
  --package-db DIR  Installed package log directory (default: /var/log/packages)
  --output FILE     Write TSV report to FILE instead of standard output
  -h, --help        Show this help
USAGE
}

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

while (($#)); do
  case $1 in
    --package-db) (($# >= 2)) || fail '--package-db requires a directory'; PACKAGE_DB=$2; shift 2 ;;
    --output) (($# >= 2)) || fail '--output requires a file'; OUTPUT=$2; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

[[ -d $PACKAGE_DB ]] || fail "Package database not found: $PACKAGE_DB"
[[ -d $TAGFILES_DIR ]] || fail "Tagfiles directory not found: $TAGFILES_DIR"
[[ -r $XFCE_INVENTORY && -r $KEEP_LIST ]] || fail 'Required keep inventories are missing.'
[[ -r $XFCE_SELECTION ]] || fail "XFCE selection is missing. Run xfce/install-xfce.sh before MLED Trim."

trim_line() {
  local value=$1
  value=${value#"${value%%[!$' \t\r\n']*}"}
  value=${value%"${value##*[!$' \t\r\n']}"}
  printf '%s' "$value"
}

valid_package_name() {
  [[ $1 =~ ^[A-Za-z0-9._+-]+$ ]]
}

# Read ADD entries from every supplied tagfile. SKP is deliberately excluded:
# SKP means "do not select for this desktop"; installed SKP packages are trimmed.
declare -A ADD_SET=()
declare -A KEEP_SET=()
EXPECTED_SERIES=(a ap d k l n t x xap)
shopt -s nullglob
tagfiles=("$TAGFILES_DIR"/*/tagfile)
((${#tagfiles[@]} == 9)) || fail "Expected exactly 9 tagfiles; found ${#tagfiles[@]}."
for series in "${EXPECTED_SERIES[@]}"; do
  [[ -r "$TAGFILES_DIR/$series/tagfile" ]] || fail "Required tested tagfile is missing: $series/tagfile"
done
for tagfile in "${tagfiles[@]}"; do
  [[ -r $tagfile ]] || fail "Cannot read tagfile: $tagfile"
  while IFS= read -r line || [[ -n $line ]]; do
    line=$(trim_line "$line")
    [[ -z $line || $line == \#* ]] && continue
    [[ $line == *:* ]] || fail "Malformed tagfile entry in $tagfile: $line"
    package=${line%%:*}
    state=${line##*:}
    valid_package_name "$package" || fail "Invalid package name in $tagfile: $package"
    case $state in
      ADD) ADD_SET["$package"]=1; KEEP_SET["$package"]=1 ;;
      SKP) ;;
      *) fail "Unknown tagfile state '$state' in $tagfile for $package" ;;
    esac
  done < "$tagfile"
done

# Protect only the packages actually selected in the Minimal/Standard/Custom
# XFCE checklist. Validate the selection against the official XFCE inventory.
declare -A XFCE_SET=()
while IFS= read -r line || [[ -n $line ]]; do
  line=$(trim_line "$line")
  [[ -z $line || $line == \#* ]] && continue
  valid_package_name "$line" || fail "Invalid package name in XFCE inventory: $line"
  XFCE_SET["$line"]=1
done < "$XFCE_INVENTORY"

xfce_count=0
while IFS= read -r line || [[ -n $line ]]; do
  line=$(trim_line "$line")
  [[ -z $line || $line == \#* ]] && continue
  valid_package_name "$line" || fail "Invalid package name in XFCE selection: $line"
  [[ ${XFCE_SET[$line]-} == 1 ]] || fail "Selected XFCE package is not in the official inventory: $line"
  KEEP_SET["$line"]=1
  xfce_count=$((xfce_count + 1))
done < "$XFCE_SELECTION"
((xfce_count > 0)) || fail "XFCE selection is empty; refusing to generate a trim manifest."

# Protect user-maintained local/SBo packages.
while IFS= read -r line || [[ -n $line ]]; do
  line=$(trim_line "$line")
  [[ -z $line || $line == \#* ]] && continue
  valid_package_name "$line" || fail "Invalid package name in packages-keep: $line"
  KEEP_SET["$line"]=1
done < "$KEEP_LIST"

# Build in temporary files, then atomically replace the manifests.
TMP_ADD=$(mktemp "$ROOT_DIR/pkglists/.packages-add.XXXXXX")
TMP_REMOVE=$(mktemp "$ROOT_DIR/pkglists/.packages-remove.XXXXXX")
TMP_REPORT=$(mktemp)
cleanup() { rm -f "$TMP_ADD" "$TMP_REMOVE" "$TMP_REPORT"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM

for package in "${!ADD_SET[@]}"; do printf '%s\n' "$package"; done | LC_ALL=C sort > "$TMP_ADD"

printf 'PACKAGE\tINSTALLED_LOG\tDECISION\tREASON\n' > "$TMP_REPORT"
count_total=0
count_keep=0
count_remove=0

for log in "$PACKAGE_DB"/*; do
  [[ -f $log ]] || continue
  filename=${log##*/}
  if [[ $filename =~ ^(.+)-[0-9][A-Za-z0-9._+~-]*-(x86_64|noarch|i[3-6]86)-[0-9]+$ ]]; then
    package=${BASH_REMATCH[1]}
  else
    fail "Cannot safely parse installed package log name: $filename"
  fi
  count_total=$((count_total + 1))
  if [[ ${KEEP_SET[$package]-} == 1 ]]; then
    decision=KEEP
    reason='ADD tagfile, selected XFCE package, or explicit packages-keep'
    count_keep=$((count_keep + 1))
  else
    decision=REMOVE
    reason='Installed package is outside the selected KISS/MLED keep set'
    printf '%s\n' "$package" >> "$TMP_REMOVE"
    count_remove=$((count_remove + 1))
  fi
  printf '%s\t%s\t%s\t%s\n' "$package" "$filename" "$decision" "$reason" >> "$TMP_REPORT"
done

LC_ALL=C sort -u "$TMP_REMOVE" -o "$TMP_REMOVE"
# Replace each generated manifest atomically after all inputs and installed
# package logs have passed validation.
chmod 0644 "$TMP_ADD" "$TMP_REMOVE"
mv -f -- "$TMP_ADD" "$ADD_LIST"
mv -f -- "$TMP_REMOVE" "$REMOVE_LIST"

if [[ $OUTPUT == '-' ]]; then
  cat "$TMP_REPORT"
else
  mkdir -p -- "$(dirname -- "$OUTPUT")"
  cp "$TMP_REPORT" "$OUTPUT"
fi

printf '\nMLED manifest generation complete.\n' >&2
printf 'Installed packages: %s | KEEP: %s | REMOVE: %s | ADD entries: %s\n' \
  "$count_total" "$count_keep" "$count_remove" "${#ADD_SET[@]}" >&2
printf 'Generated: %s, %s\n' "$ADD_LIST" "$REMOVE_LIST" >&2
printf 'No package operation was executed by this audit/generator.\n' >&2
