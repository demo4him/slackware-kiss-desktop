#!/bin/sh
# Slackware KISS Desktop - package reconciliation helper
# Inspired by Microlinux MLED's trim-desktop-base.sh.
# Default mode is a report only. Changes require the explicit --apply option.

set -eu

PROGRAM=${0##*/}
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
ADD_LIST="$PROJECT_DIR/pkglists/packages-add"
REMOVE_LIST="$PROJECT_DIR/pkglists/packages-remove"
KEEP_LIST="$PROJECT_DIR/pkglists/packages-keep"

APPLY=0
case ${1-} in
  "") ;;
  --dry-run) ;;
  --apply) APPLY=1 ;;
  --help|-h)
    cat <<USAGE
Usage: $PROGRAM [--dry-run|--apply]

  --dry-run  Show planned operations (default); change nothing.
  --apply    Apply removals and installations after confirmation.
  --help     Show this help.

Lists:
  $ADD_LIST
  $REMOVE_LIST
  $KEEP_LIST (protected packages)
USAGE
    exit 0
    ;;
  *) echo "ERROR: Unknown option: $1" >&2; exit 2 ;;
esac

fail() { echo "ERROR: $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Run this script as root."
[ -r "$ADD_LIST" ] || fail "Cannot read $ADD_LIST"
[ -r "$REMOVE_LIST" ] || fail "Cannot read $REMOVE_LIST"
[ -r "$KEEP_LIST" ] || fail "Cannot read $KEEP_LIST"
PACKAGE_DB=${KISS_PACKAGE_DB:-/var/log/packages}
SLACKPKG=${KISS_SLACKPKG:-/usr/sbin/slackpkg}
REMOVEPKG=${KISS_REMOVEPKG:-/sbin/removepkg}
[ -d "$PACKAGE_DB" ] || fail "Slackware package database $PACKAGE_DB is missing."

if [ "$APPLY" -eq 1 ]; then
  [ -x "$REMOVEPKG" ] || fail "$REMOVEPKG is not executable."
  [ -x "$SLACKPKG" ] || fail "$SLACKPKG is not executable."
fi

# Lists contain one Slackware package base name per line. Full package
# filenames, versions, shell metacharacters and inline comments are rejected.
# Installed package logs follow NAME-VERSION-ARCH-BUILD; VERSION starts
# with a digit. The digit boundary prevents NAME from matching NAME-extra.
valid_package_name() {
  case $1 in
    ""|\#*) return 1 ;;
    *-[0-9]*-x86_64-[0-9]*|*-[0-9]*-noarch-[0-9]*|*-[0-9]*-i[3-6]86-[0-9]*) return 1 ;;
    *[!A-Za-z0-9._+-]*) return 1 ;;
    *) return 0 ;;
  esac
}

installed_log() {
  wanted=$1
  found=
  count=0

  # Slackware package versions begin with a digit. Requiring that boundary
  # avoids treating "foo-bar" as an installed instance of "foo".
  for entry in "$PACKAGE_DB"/"$wanted"-[0-9]*; do
    [ -f "$entry" ] || continue
    found=$entry
    count=$((count + 1))
  done

  [ "$count" -le 1 ] || fail "More than one installed log matches '$wanted'; resolve this manually."
  [ "$count" -eq 1 ] || return 1
  printf '%s\n' "$found"
}

is_installed() {
  installed_log "$1" >/dev/null
}

read_list() {
  list_file=$1
  while IFS= read -r line || [ -n "$line" ]; do
    # Trim leading/trailing whitespace; ignore blank lines and comments.
    line=$(printf '%s\n' "$line" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
    case $line in ""|\#*) continue ;; esac
    valid_package_name "$line" || fail "Invalid entry '$line' in $list_file"
    printf '%s\n' "$line"
  done < "$list_file"
}

REMOVE_TMP=${TMPDIR:-/tmp}/kiss-trim-remove.$$
ADD_TMP=${TMPDIR:-/tmp}/kiss-trim-add.$$
KEEP_TMP=${TMPDIR:-/tmp}/kiss-trim-keep.$$
cleanup() { rm -f "$REMOVE_TMP" "$ADD_TMP" "$KEEP_TMP"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
: > "$REMOVE_TMP"
: > "$ADD_TMP"
: > "$KEEP_TMP"

# Parse directly so a validation error cannot be hidden by a successful sort.
# Normalize duplicate entries to one operation per package.
read_list "$REMOVE_LIST" > "$REMOVE_TMP"
LC_ALL=C sort -u "$REMOVE_TMP" -o "$REMOVE_TMP"
read_list "$ADD_LIST" > "$ADD_TMP"
LC_ALL=C sort -u "$ADD_TMP" -o "$ADD_TMP"
read_list "$KEEP_LIST" > "$KEEP_TMP"
LC_ALL=C sort -u "$KEEP_TMP" -o "$KEEP_TMP"

# A package must never appear in both lists.
if grep -Fxf "$REMOVE_TMP" "$ADD_TMP" >/dev/null 2>&1; then
  fail "A package appears in both packages-add and packages-remove. Resolve the conflict first."
fi
if grep -Fxf "$REMOVE_TMP" "$KEEP_TMP" >/dev/null 2>&1; then
  fail "A package appears in packages-keep and packages-remove. Remove the conflict before continuing."
fi

REMOVE_COUNT=0
ADD_COUNT=0

printf '\nSlackware KISS Desktop - package plan\n'
printf '%s\n' '===================================='

printf '\nPackages marked for installation:\n'
while IFS= read -r package; do
  [ -n "$package" ] || continue
  if is_installed "$package"; then
    printf '  KEEP    %s (already installed)\n' "$package"
  else
    printf '  INSTALL %s\n' "$package"
    ADD_COUNT=$((ADD_COUNT + 1))
  fi
done < "$ADD_TMP"

printf '\nPackages marked for removal:\n'
while IFS= read -r package; do
  [ -n "$package" ] || continue
  if is_installed "$package"; then
    printf '  REMOVE  %s\n' "$package"
    REMOVE_COUNT=$((REMOVE_COUNT + 1))
  else
    printf '  KEEP    %s (not installed)\n' "$package"
  fi
done < "$REMOVE_TMP"

printf '\nSummary: %s removal(s), %s installation(s).\n' "$REMOVE_COUNT" "$ADD_COUNT"

if [ "$APPLY" -eq 0 ]; then
  printf 'DRY-RUN: no changes have been made.\n'
  printf 'Review the lists, then use --apply when you are ready.\n'
  exit 0
fi

[ "$REMOVE_COUNT" -eq 0 ] && [ "$ADD_COUNT" -eq 0 ] && {
  printf 'Nothing to do.\n'
  exit 0
}

printf '\nWARNING: This will modify the installed Slackware system.\n'
printf 'Type APPLY to continue: '
IFS= read -r answer
[ "$answer" = APPLY ] || {
  printf 'Cancelled. No changes made.\n'
  exit 0
}

# Install the complete ADD selection first, in one slackpkg transaction just
# like the original MLED helper. Only after it succeeds do we trim outside packages.
ADD_ARGS=
while IFS= read -r package; do
  [ -n "$package" ] || continue
  if ! is_installed "$package"; then
    ADD_ARGS="$ADD_ARGS $package"
  fi
done < "$ADD_TMP"
if [ -n "$ADD_ARGS" ]; then
  # Refresh the configured Slackware mirror before resolving the selected set.
  # If update or install fails, set -e stops here and no removals are attempted.
  printf '\n==> Updating Slackware package metadata\n'
  "$SLACKPKG" update

  # Package names were validated above and cannot contain shell metacharacters.
  # Intentional splitting passes each package as one argument to slackpkg.
  printf '\n==> Installing selected Slackware packages with slackpkg\n'
  # shellcheck disable=SC2086
  "$SLACKPKG" install $ADD_ARGS
fi

# Critical safety gate: verify the complete ADD set is installed before
# allowing any package removal. A failed or incomplete install aborts trimming.
printf '\n==> Verifying selected ADD packages before removal\n'
MISSING_ADD=0
while IFS= read -r package; do
  [ -n "$package" ] || continue
  if ! is_installed "$package"; then
    printf 'ERROR: Required ADD package is still missing: %s\\n' "$package" >&2
    MISSING_ADD=$((MISSING_ADD + 1))
  fi
done < "$ADD_TMP"
[ "$MISSING_ADD" -eq 0 ] || fail "$MISSING_ADD ADD package(s) are missing; no removals were performed."

# MLED-style trim: remove every package explicitly generated into packages-remove.
while IFS= read -r package; do
  [ -n "$package" ] || continue
  if is_installed "$package"; then
    printf '\n==> Removing %s\n' "$package"
    "$REMOVEPKG" "$package"
  fi
done < "$REMOVE_TMP"

printf '\nFinished. Review slackpkg/removepkg output for errors.\n'
