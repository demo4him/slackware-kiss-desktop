#!/bin/sh
# Slackware KISS Desktop - simple MLED-style trim executor.
# Original MLED order: remove unselected packages, then install the ADD set.
set -eu
PROGRAM=${0##*/}
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
ADD_LIST="$PROJECT_DIR/pkglists/packages-add"
REMOVE_LIST="$PROJECT_DIR/pkglists/packages-remove"
APPLY=0
case ${1-} in
  "") ;;
  --dry-run) ;;
  --apply) APPLY=1 ;;
  --help|-h)
    cat <<USAGE
Usage: $PROGRAM [--dry-run|--apply]
  --dry-run  Show MLED operation order; change nothing (default).
  --apply    Remove the REMOVE list first, then install ADD in one batch.
USAGE
    exit 0 ;;
  *) echo "ERROR: Unknown option: $1" >&2; exit 2 ;;
esac
fail() { echo "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" -eq 0 ] || fail "Run this script as root."
[ -r "$ADD_LIST" ] || fail "Cannot read $ADD_LIST"
[ -r "$REMOVE_LIST" ] || fail "Cannot read $REMOVE_LIST"
SLACKPKG=${KISS_SLACKPKG:-/usr/sbin/slackpkg}
REMOVEPKG=${KISS_REMOVEPKG:-/sbin/removepkg}
if [ "$APPLY" -eq 1 ]; then
  [ -x "$REMOVEPKG" ] || fail "$REMOVEPKG is not executable."
  [ -x "$SLACKPKG" ] || fail "$SLACKPKG is not executable."
fi
valid_package_name() {
  case $1 in ""|\#*) return 1 ;; *[!A-Za-z0-9._+-]*) return 1 ;; *) return 0 ;; esac
}
read_list() {
  file=$1
  while IFS= read -r line || [ -n "$line" ]; do
    line=$(printf '%s\n' "$line" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
    case $line in ""|\#*) continue ;; esac
    valid_package_name "$line" || fail "Invalid entry '$line' in $file"
    printf '%s\n' "$line"
  done < "$file"
}
TMP_REMOVE=${TMPDIR:-/tmp}/kiss-trim-remove.$$
TMP_ADD=${TMPDIR:-/tmp}/kiss-trim-add.$$
cleanup() { rm -f "$TMP_REMOVE" "$TMP_ADD"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
read_list "$REMOVE_LIST" > "$TMP_REMOVE"
read_list "$ADD_LIST" > "$TMP_ADD"
LC_ALL=C sort -u "$TMP_REMOVE" -o "$TMP_REMOVE"
LC_ALL=C sort -u "$TMP_ADD" -o "$TMP_ADD"
grep -Fxf "$TMP_REMOVE" "$TMP_ADD" >/dev/null 2>&1 && fail "A package appears in both ADD and REMOVE."
REMOVE_COUNT=$(awk 'END {print NR+0}' "$TMP_REMOVE")
ADD_COUNT=$(awk 'END {print NR+0}' "$TMP_ADD")
printf '\nSlackware KISS Desktop - MLED package plan\n==========================================\n'
printf '\nStage 1 - REMOVE (%s packages)\n' "$REMOVE_COUNT"
while IFS= read -r package; do [ -n "$package" ] && printf '  removepkg %s\n' "$package"; done < "$TMP_REMOVE"
printf '\nStage 2 - ADD (%s packages; one slackpkg install batch)\n' "$ADD_COUNT"
if [ -s "$TMP_ADD" ]; then printf '  slackpkg install'; while IFS= read -r package; do [ -n "$package" ] && printf ' %s' "$package"; done < "$TMP_ADD"; printf '\n'; fi
printf '\nMLED order: REMOVE first, ADD second.\n'
[ "$APPLY" -eq 1 ] || { printf 'DRY-RUN: no package operations were executed.\n'; exit 0; }
[ "$REMOVE_COUNT" -eq 0 ] && [ "$ADD_COUNT" -eq 0 ] && { echo 'Nothing to do.'; exit 0; }
printf '\nWARNING: removals are performed before ADD installation, matching MLED trim order.\nReview the manifests/report first. Type APPLY to continue: '
IFS= read -r answer
[ "$answer" = APPLY ] || { echo 'Cancelled. No changes made.'; exit 0; }
while IFS= read -r package; do
  [ -n "$package" ] || continue
  printf '\n==> Removing %s\n' "$package"
  "$REMOVEPKG" "$package"
done < "$TMP_REMOVE"
if [ -s "$TMP_ADD" ]; then
  printf '\n==> Installing ADD set with one slackpkg invocation\n'
  set --
  while IFS= read -r package; do [ -n "$package" ] && set -- "$@" "$package"; done < "$TMP_ADD"
  "$SLACKPKG" install "$@"
fi
printf '\nMLED trim finished. Review slackpkg/removepkg output.\n'
