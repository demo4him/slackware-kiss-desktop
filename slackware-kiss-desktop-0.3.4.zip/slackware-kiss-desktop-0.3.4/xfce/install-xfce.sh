#!/bin/bash
# Slackware KISS Desktop - official XFCE package installer
# Slackware64 15.0; profiles are presets, with a final interactive checklist.

set -Eeuo pipefail

PROGRAM=${0##*/}
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PROJECT_DIR=$(cd -- "$SCRIPT_DIR/.." && pwd)
REPO_URL=${KISS_XFCE_REPO_URL:-rsync://slackware.uk/slackware/slackware64-15.0/slackware64/xfce/}
CACHE_DIR=${KISS_XFCE_CACHE:-/var/cache/slackware-kiss-desktop/xfce-15.0}
VERSION_FILE=${KISS_SLACKWARE_VERSION_FILE:-/etc/slackware-version}
SELECTION_FILE="$PROJECT_DIR/pkglists/xfce-selected"
PROFILE=interactive
DRY_RUN=0
USE_SAVED_SELECTION=0

usage() {
    cat <<USAGE
Usage: $PROGRAM [--profile minimal|standard|custom] [--dry-run] [--use-saved-selection]
       $PROGRAM --help

Synchronize the official Slackware64 15.0 XFCE packages, apply an optional
profile preset, and let you review the final package checklist in dialog.

Profiles:
  minimal   Core XFCE session components
  standard  Minimal plus common desktop essentials
  custom    No packages preselected

Options:
  --profile NAME  Skip the profile menu and use NAME directly
  --dry-run       Preview selection; do not create cache, sync, or install
  --use-saved-selection  Install the previously saved selection without another checklist
  -h, --help      Show this help

Optional environment overrides (mainly useful for testing):
  KISS_XFCE_REPO_URL  Official rsync URL or a local rsync source
  KISS_XFCE_CACHE     Local package cache directory
USAGE
}

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

while (($#)); do
    case $1 in
        --profile)
            (($# >= 2)) || fail "--profile requires a value."
            PROFILE=$2
            shift 2
            ;;
        --dry-run)
            DRY_RUN=1
            shift
            ;;
        --use-saved-selection)
            USE_SAVED_SELECTION=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            fail "Unknown option: $1 (use --help)."
            ;;
    esac
done

case $PROFILE in
    interactive|minimal|standard|custom) ;;
    *) fail "Unknown profile '$PROFILE'. Use minimal, standard, or custom." ;;
esac

[[ $EUID -eq 0 ]] || fail "Run this installer as root."
command -v dialog >/dev/null 2>&1 || fail "dialog is not installed."
if ((!DRY_RUN)); then
    [[ -x /usr/sbin/upgradepkg ]] || command -v upgradepkg >/dev/null 2>&1 || fail "upgradepkg is not installed."
    command -v rsync >/dev/null 2>&1 || fail "rsync is not installed."
fi

if [[ -r $VERSION_FILE ]]; then
    VERSION=$(cat "$VERSION_FILE")
    [[ $VERSION == "Slackware 15.0" ]] || fail "This module targets Slackware 15.0; detected: $VERSION"
    ARCH=$(uname -m)
    [[ $ARCH == "x86_64" ]] || fail "This module targets Slackware64 15.0; detected architecture: $ARCH"
else
    fail "Cannot verify Slackware release: $VERSION_FILE is missing or unreadable."
fi

# The inventory is independent of the package cache, so dry-run can work
# without creating directories or contacting the repository.
[[ -r $SCRIPT_DIR/packages-official ]] || fail "Official package inventory is missing or unreadable."
mapfile -t INVENTORY < <(grep -Ev '^[[:space:]]*(#|$)' "$SCRIPT_DIR/packages-official")
((${#INVENTORY[@]} > 0)) || fail "The official package inventory is empty."

declare -A PACKAGE_FILE=()
declare -A PACKAGE_DESC=(
    [Greybird]='GTK theme'
    [elementary-xfce]='Icon theme'
    [exo]='XFCE application library'
    [garcon]='Application menu library'
    [libxfce4ui]='XFCE user-interface library'
    [libxfce4util]='XFCE utility library'
    [mousepad]='Text editor'
    [thunar]='File manager'
    [thunar-volman]='Removable-media support for Thunar'
    [tumbler]='Thumbnail service'
    [xfce4-appfinder]='Application finder'
    [xfce4-clipman-plugin]='Clipboard panel plugin'
    [xfce4-dev-tools]='Developer tools'
    [xfce4-notifyd]='Notification service'
    [xfce4-panel]='Desktop panel'
    [xfce4-panel-profiles]='Panel profile manager'
    [xfce4-power-manager]='Power management'
    [xfce4-pulseaudio-plugin]='PulseAudio panel plugin'
    [xfce4-screensaver]='Screen saver and locker'
    [xfce4-screenshooter]='Screenshot utility'
    [xfce4-session]='Session manager'
    [xfce4-settings]='Settings manager'
    [xfce4-systemload-plugin]='System load panel plugin'
    [xfce4-taskmanager]='Task manager'
    [xfce4-terminal]='Terminal emulator'
    [xfce4-weather-plugin]='Weather panel plugin'
    [xfce4-whiskermenu-plugin]='Alternative application menu'
    [xfconf]='Configuration system'
    [xfdesktop]='Desktop manager'
    [xfwm4]='Window manager'
)

for base in "${INVENTORY[@]}"; do
    [[ $base =~ ^[A-Za-z0-9+_.-]+$ ]] || fail "Invalid package name in inventory: $base"
    [[ -z ${PACKAGE_FILE[$base]+present} ]] || fail "Duplicate package in inventory: $base"
    PACKAGE_FILE[$base]=""
done

TMP_SELECTION=$(mktemp) || fail "Cannot create temporary selection file."
trap 'rm -f "$TMP_SELECTION"' EXIT
trap 'exit 1' HUP INT TERM

if [[ $PROFILE == interactive && $USE_SAVED_SELECTION -eq 0 ]]; then
    PROFILE=$(dialog --clear --stdout --backtitle 'Slackware KISS Desktop' \
        --title ' Select XFCE installation profile ' \
        --menu 'Choose a starting profile. You can review every package next.' \
        12 76 3 \
        minimal 'Core XFCE session components' \
        standard 'Minimal plus common desktop essentials' \
        custom 'Custom selection - everything OFF') || {
            clear || true
            printf 'Profile selection cancelled. No packages were installed.\n'
            exit 0
        }
    clear || true
fi

# Load the chosen preset and verify that every entry exists in the live mirror.
declare -A PRESELECT=()
if [[ $PROFILE != custom ]]; then
    PROFILE_FILE="$SCRIPT_DIR/profiles/$PROFILE"
    [[ -r $PROFILE_FILE ]] || fail "Profile file is missing: $PROFILE_FILE"
    while IFS= read -r base || [[ -n $base ]]; do
        [[ $base =~ ^[[:space:]]*(#|$) ]] && continue
        base=${base//[[:space:]]/}
        [[ -n ${PACKAGE_FILE[$base]+present} ]] || fail "Profile '$PROFILE' refers to unknown or unavailable package '$base'."
        PRESELECT[$base]=1
    done < "$PROFILE_FILE"
fi

if ((USE_SAVED_SELECTION)); then
    [[ -r $SELECTION_FILE ]] || fail "Saved XFCE selection is missing: $SELECTION_FILE"
    mapfile -t SELECTED_NAMES < <(grep -Ev '^[[:space:]]*(#|$)' "$SELECTION_FILE")
    PROFILE=saved
else
    # A fresh selection is required for each run; save it for the MLED manifest generator.
    rm -f -- "$SELECTION_FILE"
    DIALOG_ARGS=()
    for base in "${INVENTORY[@]}"; do
        description=${PACKAGE_DESC[$base]:-Optional XFCE package}
        status=OFF
        [[ -n ${PRESELECT[$base]+yes} ]] && status=ON
        DIALOG_ARGS+=("$base" "$description" "$status")
    done
    if ! dialog --clear --separate-output \
        --backtitle 'Slackware KISS Desktop' \
        --title " Official XFCE Packages - $PROFILE profile " \
        --checklist 'Use SPACE to change selections. Review the profile before continuing.' \
        24 86 16 "${DIALOG_ARGS[@]}" 2>"$TMP_SELECTION"; then
        clear || true
        printf 'Package selection cancelled. No packages were installed.\n'
        exit 0
    fi
    clear || true
    mapfile -t SELECTED_NAMES < "$TMP_SELECTION"
fi
((${#SELECTED_NAMES[@]} > 0)) || {
    rm -f -- "$SELECTION_FILE"
    printf 'No packages selected. Nothing to install.\n'
    exit 0
}

write_selection_file() {
    local tmp
    tmp=$(mktemp "$PROJECT_DIR/pkglists/.xfce-selected.XXXXXX") ||
        fail "Cannot create temporary XFCE selection file."
    printf '%s\n' "${SELECTED_NAMES[@]}" > "$tmp"
    chmod 0644 "$tmp"
    mv -f -- "$tmp" "$SELECTION_FILE" ||
        fail "Cannot save selected XFCE packages to $SELECTION_FILE."
}

for base in "${SELECTED_NAMES[@]}"; do
    [[ -n ${PACKAGE_FILE[$base]+present} ]] || fail "Unexpected package returned by dialog: $base"
done

printf '\nSelected official XFCE packages (%s profile):\n' "$PROFILE"
printf '  %s\n' "${SELECTED_NAMES[@]}"
printf '\n'

if ((DRY_RUN)); then
    write_selection_file
    printf 'DRY RUN: selection validated and saved to %s; no cache was created, no repository was synchronized, and no packages were installed.\n' "$SELECTION_FILE"
    exit 0
fi

# rsync --delete requires a dedicated, verified package cache. Check every
# path component before and after creation to reject symlinked cache paths.
CACHE_DIR=${CACHE_DIR%/}
[[ $CACHE_DIR == /* ]] || fail "Package cache path must be absolute: $CACHE_DIR"
[[ $CACHE_DIR != / ]] || fail "Unsafe package cache path: $CACHE_DIR"
[[ $CACHE_DIR != *"/../"* && $CACHE_DIR != */.. ]] || fail "Unsafe parent traversal in cache path: $CACHE_DIR"
[[ $CACHE_DIR != *"/./"* && $CACHE_DIR != */. ]] || fail "Unsafe current-directory component in cache path: $CACHE_DIR"
[[ $CACHE_DIR == */xfce-15.0 ]] || fail "Use a dedicated cache directory ending in /xfce-15.0."

check_cache_path() {
    local current=""
    local component
    local -a components=()
    IFS='/' read -r -a components <<< "${CACHE_DIR#/}"
    for component in "${components[@]}"; do
        [[ -n $component ]] || continue
        current="$current/$component"
        [[ ! -L $current ]] || fail "Cache path contains a symbolic link: $current"
    done
}

check_cache_path
mkdir -p "$CACHE_DIR" || fail "Cannot create package cache: $CACHE_DIR"
check_cache_path
[[ -d $CACHE_DIR ]] || fail "Package cache is not a directory: $CACHE_DIR"

printf 'Synchronizing official XFCE packages...\n'
rsync -av --update --delete --exclude='*l10n*' "$REPO_URL" "$CACHE_DIR/" \
    || fail "XFCE repository synchronization failed. No packages were installed."

# Resolve exactly one archive for each inventory entry after synchronization.
for base in "${INVENTORY[@]}"; do
    matches=()
    shopt -s nullglob
    for file in "$CACHE_DIR"/"$base"-[0-9]*.txz; do
        [[ -f $file ]] && matches+=("$file")
    done
    shopt -u nullglob
    ((${#matches[@]} == 1)) || fail "Expected exactly one package archive for '$base' in cache; found ${#matches[@]}"
    PACKAGE_FILE[$base]=${matches[0]}
done

SELECTED_FILES=()
for base in "${SELECTED_NAMES[@]}"; do
    archive=${PACKAGE_FILE[$base]}
    xz -t -- "$archive" || fail "Package archive is corrupt or unreadable: ${archive##*/}"
    SELECTED_FILES+=("$archive")
done

if ! dialog --clear --title 'Confirm XFCE installation' \
    --yesno "Install ${#SELECTED_FILES[@]} selected official XFCE package(s) using upgradepkg --install-new?" 9 76; then
    clear || true
    printf 'Installation cancelled. No packages were installed.\n'
    exit 0
fi
clear || true

printf 'Installing selected official XFCE packages...\n'
upgradepkg --install-new "${SELECTED_FILES[@]}" \
    || fail "upgradepkg reported an error. Review its output before continuing."

write_selection_file

cat <<'DONE'

Official XFCE package installation completed.

Next step: run xwmconfig as the desktop user and select XFCE as the
preferred window manager/session for startx. Display-manager setup and
additional SlackBuilds.org packages are intentionally handled separately.
DONE
