# XFCE Minimal dependency audit — Slackware64 15.0

Audit date: 2026-11-19  
Target: Slackware64 15.0, XFCE 4.16  
Input: the nine user-supplied tagfile sets (`a`, `ap`, `d`, `k`, `l`, `n`, `t`, `x`, `xap`).

## Scope and method

This is a static cross-check of the current `xfce/profiles/minimal` selection
against the package names and `ADD`/`SKP` states in the supplied tagfiles.
The official Slackware64 15.0 `xfce/` repository was also checked to confirm
that the XFCE package names and release series used by this project exist.

Slackware package metadata does not provide a complete dependency graph for
these packages. Therefore this document is a practical coverage audit, not a
formal proof that every optional runtime feature or every ELF dependency is
satisfied. A clean-install test remains necessary.

## Minimal profile under review

The current profile contains these 12 packages:

- `exo`
- `garcon`
- `libxfce4ui`
- `libxfce4util`
- `thunar`
- `xfce4-appfinder`
- `xfce4-panel`
- `xfce4-session`
- `xfce4-settings`
- `xfconf`
- `xfdesktop`
- `xfwm4`

All 12 are present in the official Slackware64 15.0 XFCE package series.

## Base-system coverage found in the supplied tagfiles

The following relevant packages are marked `ADD` in the supplied tagfiles.

| Area | Selected packages |
|---|---|
| Core/session | `dbus`, `elogind`, `eudev` |
| GTK and XFCE support libraries | `glib`, `gtk+3`, `libnotify`, `libwnck3`, `startup-notification` |
| Desktop integration | `desktop-file-utils`, `shared-mime-info`, `hicolor-icon-theme`, `xdg-utils`, `xdg-user-dirs` |
| File manager and device integration | `gvfs`, `udisks2` |
| Policy and power integration | `polkit`, `upower` |
| X11 session | `xorg-server`, `xinit`, `xauth`, `iceauth`, `xkbcomp`, `xkeyboard-config` |
| X11 libraries | `libX11`, `libXext`, `libXrender`, `libXrandr`, `libXcursor`, `libXi`, `libXinerama`, `libSM`, `libICE`, `libXfixes`, `libXdamage`, `libXcomposite`, `libXft`, `libxcb` |
| Terminal support | `vte` |

This is good coverage for the core XFCE session and common desktop integration.
It also means the current Minimal profile does not need to duplicate these
packages in its XFCE selection.

## Standard-profile additions

The current Standard profile adds:

- `thunar-volman`
- `tumbler`
- `xfce4-notifyd`
- `xfce4-power-manager`
- `xfce4-screensaver`
- `xfce4-screenshooter`
- `xfce4-taskmanager`
- `xfce4-terminal`

The supplied tagfiles also mark the main integration packages needed by these
features as `ADD`, including `gvfs`, `udisks2`, `upower`, `polkit`, `libnotify`,
`accountsservice`, `gnome-keyring`, and `vte`.

## Findings

1. **Keep the 12-package Minimal profile unchanged for now.** The tagfiles
   already cover the main base-system, GTK, X11, D-Bus, and desktop-integration
   components identified in this first pass.
2. **Keep optional desktop services in Standard.** Thunar volume handling,
   thumbnails, notifications, power management, screensaver, screenshots,
   task manager, and terminal are useful but not all essential to a minimal
   session.
3. **Do not add a second XFCE tagfile.** The separate XFCE installer remains
   the one place that selects and installs XFCE-series packages.
4. **Do not claim dependency closure yet.** We have not installed this exact
   combination on a clean Slackware64 15.0 system, inspected every package's
   ELF linkage, or tested all runtime features.

## Next validation on a clean test installation

1. Install Slackware64 15.0 using the supplied tagfiles.
2. Run the XFCE installer with `--profile minimal --dry-run` and inspect the
   final checklist.
3. Install the reviewed selection on a disposable test system.
4. Check package integrity and unresolved shared libraries; then test login,
   session startup, panel, window manager, settings, Thunar, and D-Bus.
5. Test Standard-only features separately before promoting the profile.

No packages were installed or removed as part of this audit.
