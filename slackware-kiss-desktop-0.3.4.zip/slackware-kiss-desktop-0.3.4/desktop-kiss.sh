#!/bin/bash
# Slackware KISS Desktop 0.3.4 - main orchestrator
# KISS workflow inspired by Microlinux MLED.

set -Eeuo pipefail

PROGRAM=${0##*/}
ROOT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
TRIM="$ROOT_DIR/scripts/kiss-trim.sh"
AUDIT="$ROOT_DIR/scripts/mled-trim-audit.sh"
XFCE="$ROOT_DIR/xfce/install-xfce.sh"
SBO="$ROOT_DIR/sbo/sbo-manager.sh"
LXDM="$ROOT_DIR/display-manager/display-manager.sh"
VERSION_FILE=${KISS_SLACKWARE_VERSION_FILE:-/etc/slackware-version}
PROFILE=interactive
DRY_RUN=0
SKIP_TRIM=0
SKIP_SBO=0
SKIP_LXDM=0

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

usage() {
    cat <<USAGE
Usage: $PROGRAM [options]

Main post-install workflow for Slackware64 15.0:
  1. Select the XFCE profile and save its exact package list
  2. Generate the MLED ADD/REMOVE manifests
  3. Remove unselected packages, then install the tagfile ADD set
  4. Install the saved XFCE selection
  5. Optional SlackBuilds.org package selection
  6. LXDM configuration

Options:
  --profile NAME   XFCE preset: minimal, standard, custom, or interactive
  --dry-run        Preview XFCE selection and MLED manifests; no package changes
  --skip-trim      Skip MLED package audit and reconciliation
  --skip-sbo       Skip the optional SBo manager
  --skip-lxdm      Skip LXDM configuration
  -h, --help       Show this help

Run as root from an active local user session for automatic LXDM user detection.
USAGE
}

while (($#)); do
    case $1 in
        --profile)
            (($# >= 2)) || fail "--profile requires a value."
            PROFILE=$2; shift 2 ;;
        --dry-run) DRY_RUN=1; shift ;;
        --skip-trim) SKIP_TRIM=1; shift ;;
        --skip-sbo) SKIP_SBO=1; shift ;;
        --skip-lxdm) SKIP_LXDM=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) fail "Unknown option: $1 (use --help)." ;;
    esac
done

case $PROFILE in
    interactive|minimal|standard|custom) ;;
    *) fail "Invalid XFCE profile '$PROFILE'." ;;
esac

[[ $EUID -eq 0 ]] || fail "Run this orchestrator as root."
[[ -r $VERSION_FILE ]] || fail "Cannot read Slackware release marker: $VERSION_FILE"
[[ $(<"$VERSION_FILE") == "Slackware 15.0" ]] || fail "This project targets Slackware 15.0."
[[ $(uname -m) == x86_64 ]] || fail "This project targets Slackware64 (x86_64)."

for module in "$AUDIT" "$TRIM" "$XFCE" "$SBO" "$LXDM"; do
    [[ -x $module ]] || fail "Module is missing or not executable: $module"
done

# Fail early, before package changes, if the complete requested workflow
# cannot run. This avoids trimming the system and discovering a missing
# prerequisite only when the later XFCE/SBo/LXDM stages start.
if ((DRY_RUN == 0)); then
    command -v dialog >/dev/null 2>&1 || fail "dialog is required for XFCE package selection."
    command -v rsync >/dev/null 2>&1 || fail "rsync is required for the official XFCE package mirror."
    command -v xz >/dev/null 2>&1 || fail "xz is required to verify XFCE package archives."
    command -v upgradepkg >/dev/null 2>&1 || fail "upgradepkg is required for XFCE installation."

    if ((SKIP_TRIM == 0)); then
        [[ -x /usr/sbin/slackpkg ]] || fail "/usr/sbin/slackpkg is required for MLED Trim."
        [[ -x /sbin/removepkg ]] || fail "/sbin/removepkg is required for MLED Trim."
        MIRRORS_FILE=${KISS_SLACKPKG_MIRRORS:-/etc/slackpkg/mirrors}
        [[ -r $MIRRORS_FILE ]] || fail "Cannot read Slackpkg mirror configuration: $MIRRORS_FILE"
        grep -Eq '^[[:space:]]*(https?|ftp|rsync)://' "$MIRRORS_FILE" ||
            fail "No active Slackware mirror is configured in $MIRRORS_FILE."
    fi

    if ((SKIP_SBO == 0 || SKIP_LXDM == 0)); then
        [[ -x /usr/sbin/sbopkg ]] ||
            fail "sbopkg is required for the SBo/LXDM stages. Install/configure sbopkg first or skip both stages."
    fi

    if ((SKIP_LXDM == 0)); then
        command -v loginctl >/dev/null 2>&1 || fail "loginctl is required for automatic LXDM user detection."
        command -v getent >/dev/null 2>&1 || fail "getent is required for LXDM user detection."
        SESSION_UIDS=()
        while read -r SESSION_ID _; do
            [[ -n ${SESSION_ID:-} ]] || continue
            SESSION_INFO=$(loginctl show-session "$SESSION_ID" -p User -p Seat -p Active -p Remote 2>/dev/null) || continue
            SESSION_UID=$(awk -F= '$1=="User"{print $2}' <<< "$SESSION_INFO")
            SESSION_SEAT=$(awk -F= '$1=="Seat"{print $2}' <<< "$SESSION_INFO")
            SESSION_ACTIVE=$(awk -F= '$1=="Active"{print $2}' <<< "$SESSION_INFO")
            SESSION_REMOTE=$(awk -F= '$1=="Remote"{print $2}' <<< "$SESSION_INFO")
            if [[ $SESSION_UID =~ ^[0-9]+$ && -n $SESSION_SEAT &&
                  $SESSION_ACTIVE == yes && $SESSION_REMOTE == no ]]; then
                SESSION_UIDS+=("$SESSION_UID")
            fi
        done < <(loginctl list-sessions --no-legend)
        ((${#SESSION_UIDS[@]} > 0)) ||
            fail "No active local desktop session found. Run from the logged-in user's desktop session or use --skip-lxdm."
        mapfile -t SESSION_UIDS < <(printf '%s\n' "${SESSION_UIDS[@]}" | sort -un)
        ((${#SESSION_UIDS[@]} == 1)) ||
            fail "More than one active local desktop user found; automatic LXDM user selection is ambiguous."
    fi
fi

run_step() {
    local label=$1; shift
    printf '\n============================================================\n'
    printf ' %s\n' "$label"
    printf '============================================================\n'
    "$@"
}

printf '\nSlackware KISS Desktop 0.3.4\n'
printf 'KISS + MLED + XFCE | Slackware64 15.0\n'
printf 'XFCE profile: %s\n' "$PROFILE"

# MLED order: save the XFCE checklist selection without syncing the repository,
# trim the Slackware base, then synchronize/install the selected XFCE packages.
if [[ $PROFILE == interactive ]]; then
    run_step 'Select XFCE profile and packages' "$XFCE" --dry-run
else
    run_step "Select XFCE packages ($PROFILE preset)" "$XFCE" --profile "$PROFILE" --dry-run
fi

[[ -s "$ROOT_DIR/pkglists/xfce-selected" ]] ||
    fail "No XFCE packages were selected. The workflow cannot continue."

if ((SKIP_TRIM == 0)); then
    AUDIT_REPORT=${KISS_MLED_AUDIT_REPORT:-/var/log/slackware-kiss-desktop-mled-audit.tsv}
    run_step 'Generate MLED ADD/REMOVE manifests' "$AUDIT" --output "$AUDIT_REPORT"
    if ((DRY_RUN)); then
        run_step 'MLED package plan (REMOVE then ADD)' "$TRIM" --dry-run
    else
        run_step 'MLED base trim (REMOVE then ADD)' "$TRIM" --apply
    fi
else
    printf '\nMLED package audit and reconciliation skipped by request.\n'
fi

if ((DRY_RUN)); then
    printf '\nDRY-RUN complete. XFCE selection and package manifests were saved; no cache was created, no repository was synchronized, and no system packages were changed. SBo and LXDM were not run.\n'
    exit 0
fi

run_step 'Install saved official XFCE selection' "$XFCE" --use-saved-selection

if ((SKIP_SBO == 0)); then
    run_step 'Optional SlackBuilds.org packages' "$SBO"
else
    printf '\nSBo Manager skipped by request.\n'
fi

if ((SKIP_LXDM == 0)); then
    run_step 'LXDM configuration' "$LXDM"
else
    printf '\nLXDM configuration skipped by request.\n'
fi

printf '\nSlackware KISS Desktop workflow finished.\n'
printf 'Review each module output and reboot when ready to test LXDM.\n'
