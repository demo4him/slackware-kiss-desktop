# Changelog

## 0.3.4 — MLED Trim manifest generation

- Preserved all nine tested project tagfiles byte-for-byte.
- `packages-add` is generated from every unique `ADD` tagfile entry.
- `packages-remove` is generated from installed package logs by subtracting
  tagfile ADD, the exact XFCE checklist selection, and explicit
  `packages-keep`.
- The XFCE installer records the selected Minimal/Standard/Custom package
  names in `pkglists/xfce-selected`; unselected XFCE inventory packages are
  no longer automatically protected.
- Tagfile SKP packages and all other installed packages outside the keep set
  are included in the removal manifest.
- No dependency audit is performed, following the user's explicit MLED/KISS
  policy and established Slackware package baseline.
- Main workflow installs the selected XFCE profile first, then generates the
  MLED manifests using that exact selection.
- Package execution order: refresh Slackware metadata when needed, install the
  missing ADD set, verify every ADD package is present, then remove packages
  outside the keep set. A failed/incomplete ADD install aborts before removal.
- `slackpkg install` receives the missing ADD package set in one operation.
- The package executor retains dry-run and explicit APPLY confirmation.
- The orchestrator checks critical prerequisites before beginning destructive
  package work, including the configured Slackware mirror, sbopkg (unless
  skipped), and an active local session for automatic LXDM user detection.
- XFCE Minimal/Standard/Custom package definitions, SBo Manager, and LXDM
  module behavior remain unchanged; the XFCE installer additionally records
  its selected package names for the trim generator.
