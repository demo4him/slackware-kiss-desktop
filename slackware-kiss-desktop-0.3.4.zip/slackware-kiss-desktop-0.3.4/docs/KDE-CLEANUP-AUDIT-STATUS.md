# KDE cleanup status — Slackware KISS Desktop 0.3.4

KDE is outside the selected KISS/XFCE package set. KDE packages installed on a
full Slackware installation are included in `packages-remove` unless their
package base names are explicitly protected by tagfile `ADD`, the official
XFCE inventory, or `pkglists/packages-keep`.

The project does not perform a per-package KDE dependency audit. This follows
the user's explicit MLED-style instruction: first ensure the selected ADD set
is installed, then remove everything outside the keep set. Qt packages selected
by the tested tagfiles remain protected because they are part of `ADD`.
