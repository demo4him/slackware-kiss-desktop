# MLED porting policy — Slackware KISS Desktop 0.3.4

Target: Slackware64 15.0  
Reference workflow: Microlinux MLED `trim-desktop-base.sh` and explicit package lists.

## Fixed project decisions

- Keep the nine tested tagfiles (`a`, `ap`, `d`, `k`, `l`, `n`, `t`, `x`, `xap`) byte-for-byte unchanged.
- Preserve every unique `ADD` package from those tagfiles.
- Preserve the official XFCE package inventory so Minimal, Standard, and Custom profile selection remains available.
- Preserve explicit local/SBo packages listed in `pkglists/packages-keep`.
- Treat XFCE as the desktop environment; KDE and other packages outside the keep set are removed.
- Retain Qt and non-KDE Qt packages selected by the tagfiles.
- Keep the tested XFCE installer, SBo Manager, and LXDM modules unchanged.

## Tagfile interpretation

`ADD` entries are written to `packages-add` and protected. `SKP` entries are not
selected; if installed, they are outside the keep set and are removed. Packages
not present as `ADD` entries are also outside the keep set unless they belong to
the official XFCE inventory or are explicitly listed in `packages-keep`.

## MLED manifest generation and execution

`scripts/mled-trim-audit.sh` generates the manifests for the current installed
system:

1. `packages-add` receives every unique `ADD` entry from all nine tagfiles.
2. The keep set is formed from tagfile `ADD`, `xfce/packages-official`, and
   `pkglists/packages-keep`.
3. `packages-remove` receives every installed package whose base name is not
   in that keep set.
4. `scripts/kiss-trim.sh` installs missing ADD packages first, in one
   `slackpkg install` invocation.
5. After the ADD operation succeeds, it removes every package in
   `packages-remove` using `removepkg`.

No dependency audit or reverse-dependency analysis is performed. This is the
user's explicit project policy, based on the long-tested Slackware package
selection and the desire to avoid further per-package review. The resulting
cleanup is intentionally broad and is designed for this project's tested
Slackware64 15.0 configuration, not arbitrary Slackware installations.

`kiss-trim.sh` retains dry-run support and requires the user to type `APPLY`
before package changes. Additional local or third-party packages that must
survive cleanup belong in `packages-keep`, one package base name per line.

## Main workflow

`desktop-kiss.sh` coordinates:

1. MLED manifest generation and package reconciliation;
2. XFCE Minimal, Standard, or Custom installation;
3. optional SBo Manager;
4. LXDM configuration.

The tested XFCE, SBo, and LXDM modules are reused rather than rewritten.
